import React from 'react';
export default function Home() {
  return <h1>Welcome to Personal Finance Manager</h1>;
}